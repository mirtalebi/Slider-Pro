package com.mirtalebi.sliderpro;

interface SliderSelectionCallBack {
    void select();
    void deselect();
}
