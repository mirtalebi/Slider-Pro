package com.mirtalebi.sliderpro;

import android.view.View;

class SlideModel {

    private View view;

    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }
}
